#include <stdio.h>  // 標準輸入輸出函式庫，用於 printf() 等函式
#include <stdlib.h> // 標準函式庫，用於 rand(), srand() 等函式
#include <math.h>   // 數學函式庫，用於 cos(), sin(), sqrt(), fabs() 等函式
#include <stdbool.h> // 布林型別支援，用於使用 bool 型別
#include <time.h>   // 時間函式庫，用於生成隨機數種子

#define PI 3.14159265358979323846 // 定義圓周率常數，供計算圓形座標時使用

// 起終點線的座標，這條線用於判斷是否完成一圈
double x_start = 0.0, y_start = -1.0; // 起點座標 (x_start, y_start)
double x_end = 0.0, y_end = 1.0;     // 終點座標 (x_end, y_end)

// 線段交叉判斷函式
bool lineCrossed(double x_prev, double y_prev, // 前一點的座標
                 double x_curr, double y_curr) // 當前點的座標
{
    // 計算前一點與線段的相對位置
    double side1 = (x_prev - x_start) * (y_end - y_start) - (y_prev - y_start) * (x_end - x_start);
    // 計算當前點與線段的相對位置
    double side2 = (x_curr - x_start) * (y_end - y_start) - (y_curr - y_start) * (x_end - x_start);
    // 如果兩點在線段的兩側，則返回 true，表示穿越線段
    return (side1 * side2 < 0);
}

// 計算點到線的距離，用於重置狀態（避免因抖動重複判斷）
double distanceToLine(double x, double y) // 點的座標
{
    double dx = x_end - x_start; // 計算線段的水平距離
    double dy = y_end - y_start; // 計算線段的垂直距離
    double norm = sqrt(dx * dx + dy * dy); // 計算線段的長度
    if (norm == 0.0) // 如果線段長度為 0，返回點到起點的距離
        return sqrt((x - x_start) * (x - x_start) + (y - y_start) * (y - y_start));
    // 返回點到線段的垂直距離
    return fabs(dy * x - dx * y + x_end * y_start - y_end * x_start) / norm;
}

int main()
{
    srand((unsigned int)time(NULL)); // 使用當前時間作為隨機數種子，確保每次執行結果不同

    // 模擬設定
    int numLaps = 3;           // 模擬的圈數，設定為 3 圈
    int pointsPerLap = 100;    // 每圈的點數，設定為 100 點
    double radius = 1.0;       // 圓的半徑，設定為 1.0
    double centerX = 0.5;      // 圓心的 X 座標，右偏以保證穿越 x = 0
    double centerY = 0.0;      // 圓心的 Y 座標，設定為 0.0
    double noiseScale = 0.002; // GPS 偏移範圍 ±0.002 (~20cm)，模擬隨機抖動
    double threshold = 0.1;    // 離線段多遠才重置 crossingFlag，設定為 0.1

    int lapCount = 0;          // 初始化圈數計數器
    bool crossingFlag = false; // 初始化穿越標記，避免重複計數

    // 設定起始座標為圓上的第一個點
    double x_prev = centerX + radius * cos(0); // 起始點的 X 座標
    double y_prev = centerY + radius * sin(0); // 起始點的 Y 座標

    printf("=== Lap Counter Demo Start ===\n"); // 輸出開始訊息
    for (int i = 1; i <= numLaps * pointsPerLap; i++) { // 模擬每個點
        double angle = 2 * PI * i / pointsPerLap; // 計算當前點的角度

        // 計算理想圓形座標
        double x_ideal = centerX + radius * cos(angle); // 理想 X 座標
        double y_ideal = centerY + radius * sin(angle); // 理想 Y 座標

        // 加上隨機偏移模擬 GPS 抖動
        double noise_x = (((rand() % 1001) - 500) / 500.0) * noiseScale; // X 偏移
        double noise_y = (((rand() % 1001) - 500) / 500.0) * noiseScale; // Y 偏移

        double x_curr = x_ideal + noise_x; // 當前點的 X 座標
        double y_curr = y_ideal + noise_y; // 當前點的 Y 座標

        // 判斷是否穿越線段
        if (lineCrossed(x_prev, y_prev, x_curr, y_curr) && !crossingFlag) {
            lapCount++; // 增加圈數
            crossingFlag = true; // 標記為正在穿越
            printf("Lap %d detected at theta =%.2f rad, pos=(%.6f, %.6f)\n",
                   lapCount, angle, x_curr, y_curr); // 輸出圈數資訊
        }
        // 如果離開線段區域，允許下次觸發
        else if (distanceToLine(x_curr, y_curr) > threshold) {
            crossingFlag = false; // 重置穿越標記
        }

        x_prev = x_curr; // 更新前一點的 X 座標
        y_prev = y_curr; // 更新前一點的 Y 座標
    }

    printf("=== Final lap count = %d ===\n", lapCount); // 輸出最終圈數
    return 0; // 程式結束
}